export { Home } from "./Home";
export { Login } from "./Login";
export { News } from "./News";
export { Welcome } from "./Welcome";
